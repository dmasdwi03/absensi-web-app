<?php
// Koneksi ke database
$host = 'localhost:3306'; // Ganti dengan host database Anda
$user = 'root'; // Ganti dengan username database Anda
$password = 'dimas'; // Ganti dengan password database Anda
$database = 'absen'; // Ganti dengan nama database Anda

$koneksi = mysqli_connect($host, $user, $password, $database);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Tangkap data dari form
$nim = $_POST['nim'];
$nama = $_POST['nama'];
$tanggal = $_POST['tanggal'];

// Query untuk menyimpan data ke tabel absen
$query = "INSERT INTO absen(nim, nama, tanggal) VALUES ('$nim', '$nama', '$tanggal')";

// Eksekusi query
if (mysqli_query($koneksi, $query)) {
    echo "Data berhasil disimpan.";
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
}

// Tutup koneksi
mysqli_close($koneksi);
?>
